package com.example.macstudent.day13;

/**
 * Created by macstudent on 2018-04-20.
 */

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ContactAdapter extends BaseAdapter {
    String names[] = {"Jk", "KK", "LK", "MK", "NK", "OK", "PK"};
    String phones[] = {"123", "234", "345", "456", "567", "678", "789"};
    LayoutInflater layoutInflater;
    Context context;
    TextView txtInitial;
    TextView txtPhone;
    View convertView;

    ContactAdapter(Context context) {
        this.context = context;
        layoutInflater = (LayoutInflater.from(context));
    }

    @Override
    public int getCount() {
        return names.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        convertView = layoutInflater.inflate(R.layout.contact_grid, null);

        txtInitial = convertView.findViewById(R.id.txtInitial);
        txtInitial.setText(String.valueOf(names[i].charAt(0)));

        txtPhone = convertView.findViewById(R.id.txtPhone);
        txtPhone.setText(phones[i]);

        return convertView;
    }
}