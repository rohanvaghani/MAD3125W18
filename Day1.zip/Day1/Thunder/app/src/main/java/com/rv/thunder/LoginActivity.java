package com.rv.thunder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnLogin,btnRegister;
    EditText editUsername, editPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin = (Button)findViewById(R.id.btnLogin);
        btnRegister = (Button)findViewById(R.id.btnRegister);
        editUsername = (EditText)findViewById(R.id.editUsername);
        editPassword = (EditText)findViewById(R.id.editPassword);

        btnLogin.setOnClickListener(this);
        btnRegister.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btnLogin.getId()) {
            String uname  = editUsername.getText().toString();
            String password = editPassword.getText().toString();
            Toast.makeText(this, "Username : " +uname+ " Password : " +password, Toast.LENGTH_SHORT).show();
        }
        else if(view.getId() == btnRegister.getId()) {
            Toast.makeText(this, "Register Clicked", Toast.LENGTH_SHORT).show();
        }
    }
}