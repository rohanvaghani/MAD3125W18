package com.rv.thunder;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnSubmit;
    TextView ttDOB;
    Calendar calendar;
    DBHelper dbHelper;
    SQLiteDatabase thunderDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(this);

        dbHelper = new DBHelper(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btnSubmit.getId()) {
            insertUser();
            displayData();
        }

    }


    private void insertUser() {
        EditText txtName = (EditText) findViewById(R.id.txtName);
        EditText txtPhone = (EditText) findViewById(R.id.txtPhone);
        EditText txtEmail = (EditText) findViewById(R.id.txtEmail);
        EditText txtPassword = (EditText) findViewById(R.id.txtPassword);
        EditText txtCarPlate = (EditText) findViewById(R.id.txtCarPlate);

        String name = txtName.getText().toString();
        String phone = txtPhone.getText().toString();
        String email = txtEmail.getText().toString();
        String password = txtPassword.getText().toString();
        String carplate = txtCarPlate.getText().toString();

        ContentValues cv = new ContentValues();
        cv.put("Name",name);
        cv.put("Phone",phone);
        cv.put("Email",email);
        cv.put("Password",password);
        cv.put("CarPlate",carplate);

        try {
            thunderDB = dbHelper.getWritableDatabase();
            thunderDB.insert("User_Info",null,cv);
        }catch (Exception e){
            Log.e("Insert User",e.getMessage());
        }
        thunderDB.close();

    }

    private void displayData() {
        try {
            thunderDB = dbHelper.getReadableDatabase();
            String columns[] = {"Name","Phone","Email","Password","CarPlate"};
            Cursor cursor = thunderDB.query("User_Info",columns,null,null,null,null,null);

            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndex("Name"));
                String phone = cursor.getString(cursor.getColumnIndex("Phone"));
                String email = cursor.getString(cursor.getColumnIndex("Email"));
                String password = cursor.getString(cursor.getColumnIndex("Password"));
                String carplate = cursor.getString(cursor.getColumnIndex("CarPlate"));

                Toast.makeText(this, name +"\n" + phone + "\n" + email + "\n" + password + "\n" + carplate, Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            Log.e("RegisterActivity","Unable to fetch records");
        }
        thunderDB.close();
    }

}
